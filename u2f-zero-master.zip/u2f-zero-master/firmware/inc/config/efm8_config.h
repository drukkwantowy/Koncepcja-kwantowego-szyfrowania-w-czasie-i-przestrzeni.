#ifndef __SILICON_LABS_EFM8_CONFIG_H
#define __SILICON_LABS_EFM8_CONFIG_H

// $[USB driver options]
#define EFM8PDL_USB0_USE                1
#define EFM8PDL_USB0_IN_DATA_ENABLED    1
#define EFM8PDL_USB0_OUT_DATA_ENABLED   1
// [USB driver options]$

#endif // __SILICON_LABS_EFM8_CONFIG_H
