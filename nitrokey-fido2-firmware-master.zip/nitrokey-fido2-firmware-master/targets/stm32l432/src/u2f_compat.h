
#ifndef U2F_COMPAT_H
#define U2F_COMPAT_H

// FIXME finish or remove sanity check handling
#define sanity_check_passed     (1)

#define u2f_delay(ms)       delay(ms)
#define data


#endif //U2F_COMPAT_H
