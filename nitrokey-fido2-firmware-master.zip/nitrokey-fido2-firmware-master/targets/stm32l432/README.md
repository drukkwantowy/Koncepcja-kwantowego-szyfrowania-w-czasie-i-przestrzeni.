# STM32L432 Solo

Check out our [official documentation](https://docs.solokeys.io/solo/building/)
for instructions on building and programming!
