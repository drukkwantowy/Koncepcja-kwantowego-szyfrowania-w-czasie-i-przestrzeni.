Documentation of the `master` branch is deployed to Netlify automatically.

To host or develop locally:

```
pip install mkdocs mkdocs-material markdown-include
```

`mkdocs serve` and visit [localhost:8000](http://localhost:8000).

The file `runtime.txt` is necessary to tell Netlify to use Python3.
