Welcome to the technical documentation for [solokeys/solo](https://github.com/solokeys/solo).

Use the table of contents on the left to browse this documentation.

