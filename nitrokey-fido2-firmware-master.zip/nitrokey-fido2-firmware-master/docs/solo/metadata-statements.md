For information on what this is, see the [spec](https://fidoalliance.org/specs/fido-v2.0-rd-20180702/fido-metadata-statement-v2.0-rd-20180702.html#fido2-example).
## CTAP2

```
{!metadata/Solo-FIDO2-CTAP2-Authenticator.json!}
```

## U2F

```
{!metadata/Solo-FIDO2-U2F-Authenticator.json!}
```
